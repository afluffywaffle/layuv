import 'annotation.dart';
import 'reading_position.dart';

abstract interface class AnnotationStoreInterface {
  Future<List<Annotation>> loadAnnotations();
  Future<ReadingPosition?> loadPosition();
  Future<void> saveAnnotation(Annotation annotation);
  Future<void> deleteAnnotation(String id);
  Future<void> deleteAll(List<String> ids);
  Future<void> savePosition(ReadingPosition position);
  Future<double> fractionForText(String selectedText, String prefix, String suffix);
}
