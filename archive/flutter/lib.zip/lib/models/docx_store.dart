import 'dart:convert';
import 'dart:io';
import 'package:archive/archive_io.dart';
import 'package:docx_to_text/docx_to_text.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'annotation.dart';
import 'annotation_store_interface.dart';
import 'reading_position.dart';

// ---------------------------------------------------------------------------
// OOXML run-property helpers
// ---------------------------------------------------------------------------
//
// Tool → run-property mapping (1-to-1 with Word/Pages/Docs):
//
//   highlight        → <w:highlight w:val="yellow"/>
//   underline        → <w:u w:val="single"/>
//   doubleUnderline  → <w:u w:val="double"/>
//   strikethrough    → <w:strike/>
//   wavyUnderline    → <w:u w:val="wave"/>
//   bookmark         → <w:bookmarkStart> / <w:bookmarkEnd>  (no rPr needed)
//   comment / note   → <w:comment> anchor only (no extra rPr)
//   inkAnnotation    → <w:highlight w:val="yellow"/>  (fallback)
//
// Annotations that carry a note or tag always get a comment anchor in addition
// to their run property. The comment text is just the note — no [tool:X] header.
//
// Every modified run also carries a <w:rPrChange w:author="Léamh"> so that:
//   1. Word/Pages/Docs show it as a tracked formatting change (author = Léamh).
//   2. Phase 2 loadAnnotations can recover Léamh's annotations by scanning for
//      w:author="Léamh" without any text search.

class DocxStore implements AnnotationStoreInterface {
  final String filePath;

  Future<void> _writeLock = Future.value();

  static const _bookmarkChannel =
      MethodChannel('com.afluffywaffle.layuv/bookmarks');

  DocxStore({required this.filePath});

  Future<void> _resolveAccess() async {
    if (!Platform.isMacOS) return;
    try {
      await _bookmarkChannel.invokeMethod('resolveBookmark', filePath);
    } catch (_) {}
  }

  Future<T> _serialized<T>(Future<T> Function() fn) {
    final next = _writeLock.then((_) => fn());
    _writeLock = next.then((_) {}, onError: (_) {});
    return next;
  }

  // ---------------------------------------------------------------------------
  // XML helpers
  // ---------------------------------------------------------------------------

  static String _esc(String s) => s
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&apos;');

  static String _unesc(String s) => s
      .replaceAll('&apos;', "'")
      .replaceAll('&quot;', '"')
      .replaceAll('&gt;', '>')
      .replaceAll('&lt;', '<')
      .replaceAll('&amp;', '&');

  // Returns the OOXML <w:rPr> fragment (inner content only, no outer tags)
  // that represents [tool]. Returns empty string for tools that don't use rPr.
  static String _rPrForTool(AnnotationTool tool) => switch (tool) {
        AnnotationTool.highlight ||
        AnnotationTool.comment ||
        AnnotationTool.inkAnnotation =>
          '<w:highlight w:val="yellow"/>',
        AnnotationTool.underline => '<w:u w:val="single"/>',
        AnnotationTool.doubleUnderline => '<w:u w:val="double"/>',
        AnnotationTool.strikethrough => '<w:strike/>',
        AnnotationTool.wavyUnderline => '<w:u w:val="wave"/>',
        AnnotationTool.bookmark => '', // handled via bookmarkStart/End
      };

  // Builds a clean comment element — note text only, no metadata header.
  static String _buildComment({
    required int xmlId,
    required Annotation a,
  }) {
    final noteXml = (a.note != null && a.note!.isNotEmpty)
        ? '<w:p><w:r><w:t xml:space="preserve">${_esc(a.note!)}</w:t></w:r></w:p>'
        : '<w:p><w:r><w:t xml:space="preserve"/></w:r></w:p>';

    final tagLine = a.tag != null
        ? '<w:p><w:r><w:t xml:space="preserve">[${a.tag!.name}]</w:t></w:r></w:p>'
        : '';

    return '''<w:comment w:id="$xmlId" w:author="Léamh" w:date="${a.timestamp.toUtc().toIso8601String()}">
  <w:p>
    <w:pPr><w:pStyle w:val="CommentText"/></w:pPr>
    <w:r><w:rPr><w:rStyle w:val="CommentReference"/></w:rPr><w:annotationRef/></w:r>
  </w:p>
  $noteXml$tagLine</w:comment>''';
  }

  // ---------------------------------------------------------------------------
  // ZIP helpers
  // ---------------------------------------------------------------------------

  Archive _decodeZip(List<int> bytes) => ZipDecoder().decodeBytes(bytes);

  String? _entryString(Archive archive, String name) {
    final entry = archive.findFile(name);
    if (entry == null) return null;
    return utf8.decode(entry.content as List<int>);
  }

  // ---------------------------------------------------------------------------
  // Reading position  (stored in leamh/position.json)
  // ---------------------------------------------------------------------------

  @override
  Future<ReadingPosition?> loadPosition() async {
    try {
      final bytes = await File(filePath).readAsBytes();
      final archive = _decodeZip(bytes);
      final raw = _entryString(archive, 'leamh/position.json');
      if (raw == null) return null;
      final json = jsonDecode(raw) as Map<String, dynamic>;
      return ReadingPosition.fromJson(json);
    } catch (e) {
      debugPrint('DocxStore.loadPosition error: $e');
      return null;
    }
  }

  @override
  Future<void> savePosition(ReadingPosition position) =>
      _serialized(() => _savePositionInner(position));

  Future<void> _savePositionInner(ReadingPosition position) async {
    try {
      await _resolveAccess();
      final bytes = await File(filePath).readAsBytes();
      var archive = _decodeZip(bytes);
      final posJson = utf8.encode(jsonEncode(position.toJson()));
      archive = _replaceOrAddEntry(archive, 'leamh/position.json', posJson);
      archive = _ensureContentType(archive);
      await _writeArchive(archive);
    } catch (e) {
      debugPrint('DocxStore.savePosition error: $e');
    }
  }

  // ---------------------------------------------------------------------------
  // Load annotations
  // ---------------------------------------------------------------------------

  @override
  Future<List<Annotation>> loadAnnotations() async {
    try {
      final bytes = await File(filePath).readAsBytes();
      final archive = _decodeZip(bytes);
      final commentsXml = _entryString(archive, 'word/comments.xml');
      final documentXml = _entryString(archive, 'word/document.xml') ?? '';
      if (commentsXml == null) return [];
      return _parseComments(commentsXml, documentXml);
    } catch (e) {
      debugPrint('DocxStore.loadAnnotations error: $e');
      return [];
    }
  }

  // ---------------------------------------------------------------------------
  // _parseComments — legacy + new format
  //
  // Legacy format:  w:author = annotation ID, header "[tool:X] N% — "text""
  // New format:     w:author = "Léamh", note text only (tool recovered from
  //                 document.xml rPrChange in Phase 2 — for now falls back to
  //                 highlight for Léamh-authored comments without a legacy header).
  // Native Word:    anything else — imported as comment tool.
  // ---------------------------------------------------------------------------

  static ({String text, double position}) _extractSelectedTextAndPosition(
      String documentXml, String commentId) {
    final startTag = '<w:commentRangeStart w:id="$commentId"/>';
    final endTag = '<w:commentRangeEnd w:id="$commentId"/>';
    final si = documentXml.indexOf(startTag);
    final ei = documentXml.indexOf(endTag);
    if (si < 0 || ei < 0 || ei <= si) return (text: '', position: 0.0);

    final segment = documentXml.substring(si, ei);
    final texts = RegExp(r'<w:t[^>]*>(.*?)</w:t>', dotAll: true)
        .allMatches(segment)
        .map((m) => m.group(1)!)
        .join('');

    final map = _buildPlainMap(documentXml);
    final totalChars = map.plain.length;
    if (totalChars == 0) return (text: texts, position: 0.0);

    int plainIdx = 0;
    for (int k = 0; k < map.xmlOffsets.length; k++) {
      if (map.xmlOffsets[k] >= si) {
        plainIdx = k;
        break;
      }
    }
    return (
      text: texts,
      position: (plainIdx / totalChars).clamp(0.0, 1.0),
    );
  }

  static List<Annotation> _parseComments(String xml, String documentXml) {
    final results = <Annotation>[];

    final commentRe =
        RegExp(r'<w:comment\s([^>]*)>(.*?)</w:comment>', dotAll: true);
    final idAttr = RegExp(r'w:id="([^"]*)"');
    final authorAttr = RegExp(r'w:author="([^"]*)"');
    final dateAttr = RegExp(r'w:date="([^"]*)"');

    // Legacy Léamh header: [tool:X] [tag:Y] Z% — "selected text"
    final legacyHeaderRe = RegExp(
      r'\[tool:(\w+)\](?:\s\[tag:(\w+)\])?\s(\d+)%\s—\s"(.*)"',
      dotAll: true,
    );

    final wtRe = RegExp(r'<w:t[^>]*>(.*?)</w:t>', dotAll: true);

    for (final cm in commentRe.allMatches(xml)) {
      try {
        final attrs = cm.group(1)!;
        final body = cm.group(2)!;

        final commentId = idAttr.firstMatch(attrs)?.group(1) ?? '';
        final authorRaw = _unesc(authorAttr.firstMatch(attrs)?.group(1) ?? '');
        final dateStr = dateAttr.firstMatch(attrs)?.group(1);
        if (dateStr == null) continue;

        final timestamp = DateTime.parse(dateStr);
        final texts = wtRe
            .allMatches(body)
            .map((m) => _unesc(m.group(1)!))
            .toList();

        if (texts.isEmpty) continue;

        final isLegacyLeamh = texts.any((t) => legacyHeaderRe.hasMatch(t));

        if (isLegacyLeamh) {
          // ── Legacy Léamh format ─────────────────────────────────────────
          if (authorRaw.isEmpty) continue;

          String? headerText;
          int headerIdx = -1;
          for (int i = 0; i < texts.length; i++) {
            if (legacyHeaderRe.hasMatch(texts[i])) {
              headerText = texts[i];
              headerIdx = i;
              break;
            }
          }
          if (headerText == null) continue;

          final hm = legacyHeaderRe.firstMatch(headerText)!;
          final toolName = hm.group(1)!;
          final tagName = hm.group(2);
          final pctStr = hm.group(3)!;
          final selectedText = hm.group(4)!;

          AnnotationTool tool;
          try {
            tool = AnnotationTool.values.byName(toolName);
          } catch (_) {
            tool = AnnotationTool.highlight;
          }

          AnnotationTag? tag;
          if (tagName != null) {
            try {
              tag = AnnotationTag.values.byName(tagName);
            } catch (_) {}
          }

          final noteTexts = texts.sublist(headerIdx + 1);
          final note = noteTexts.isNotEmpty ? noteTexts.join('\n') : null;

          results.add(Annotation(
            id: authorRaw,
            selectedText: selectedText,
            prefix: '',
            suffix: '',
            tool: tool,
            tag: tag,
            note: note?.isEmpty == true ? null : note,
            timestamp: timestamp,
            position: int.parse(pctStr) / 100.0,
          ));
        } else if (authorRaw == 'Léamh') {
          // ── New Léamh format ────────────────────────────────────────────
          // Tool is encoded in document.xml rPrChange (Phase 2).
          // For now, recover selected text from comment anchors and use
          // comment tool as placeholder; tool will be inferred in Phase 2.
          if (commentId.isEmpty) continue;
          final extracted =
              _extractSelectedTextAndPosition(documentXml, commentId);

          // Filter out annotation-ref placeholder text.
          final noteTexts = texts
              .where((t) => t.trim().isNotEmpty && !RegExp(r'^\s*$').hasMatch(t))
              .toList();
          final note = noteTexts.isNotEmpty ? noteTexts.join('\n') : null;

          // Parse tag from [tagname] line if present.
          AnnotationTag? tag;
          final tagMatch =
              RegExp(r'^\[(\w+)\]$').firstMatch(noteTexts.lastOrNull ?? '');
          if (tagMatch != null) {
            try {
              tag = AnnotationTag.values.byName(tagMatch.group(1)!);
            } catch (_) {}
          }

          final cleanNote = (tag != null && noteTexts.length > 1)
              ? noteTexts.sublist(0, noteTexts.length - 1).join('\n')
              : (tag != null ? null : note);

          debugPrint('DocxStore: loading Léamh annotation — tool=comment selectedText="${extracted.text.substring(0, extracted.text.length.clamp(0, 40))}" position=${extracted.position}');
          results.add(Annotation(
            id: 'leamh_$commentId',
            selectedText: extracted.text.isNotEmpty
                ? extracted.text
                : (noteTexts.firstOrNull ?? ''),
            prefix: '',
            suffix: '',
            tool: AnnotationTool.comment, // refined in Phase 2
            tag: tag,
            note: cleanNote?.isEmpty == true ? null : cleanNote,
            timestamp: timestamp,
            position: extracted.position,
          ));
        } else {
          // ── Native Word / Pages / Docs comment ──────────────────────────
          if (commentId.isEmpty) continue;
          final extracted =
              _extractSelectedTextAndPosition(documentXml, commentId);
          if (extracted.text.isEmpty) continue;

          final note = texts.join(' ').trim();
          results.add(Annotation(
            id: 'word_$commentId',
            selectedText: extracted.text,
            prefix: '',
            suffix: '',
            tool: AnnotationTool.comment,
            note: note.isEmpty ? null : note,
            timestamp: timestamp,
            position: extracted.position,
          ));
        }
      } catch (e) {
        debugPrint('DocxStore: skipping malformed comment: $e');
      }
    }

    results.sort((a, b) => a.position.compareTo(b.position));
    return results;
  }

  // ---------------------------------------------------------------------------
  // Save / delete
  // ---------------------------------------------------------------------------

  @override
  Future<void> saveAnnotation(Annotation annotation) =>
      _serialized(() async {
        final list = await loadAnnotations();
        final idx = list.indexWhere((a) => a.id == annotation.id);
        if (idx >= 0) {
          list[idx] = annotation;
        } else {
          list.add(annotation);
        }
        await _writeAllAnnotations(list);
      });

  @override
  Future<void> deleteAnnotation(String id) =>
      _serialized(() async {
        final list = await loadAnnotations();
        list.removeWhere((a) => a.id == id);
        await _writeAllAnnotations(list);
      });

  @override
  Future<void> deleteAll(List<String> ids) =>
      _serialized(() async {
        final set = ids.toSet();
        final list = await loadAnnotations();
        list.removeWhere((a) => set.contains(a.id));
        await _writeAllAnnotations(list);
      });

  // ---------------------------------------------------------------------------
  // _writeAllAnnotations — Phase 1 write path
  // ---------------------------------------------------------------------------

  Future<void> _writeAllAnnotations(List<Annotation> annotations) async {
    await _resolveAccess();
    final bytes = await File(filePath).readAsBytes();
    var archive = _decodeZip(bytes);

    // Annotations that need a comment (have a note or tag).
    final commentable = annotations
        .asMap()
        .entries
        .where((e) =>
            (e.value.note != null && e.value.note!.isNotEmpty) ||
            e.value.tag != null)
        .toList();

    // Build word/comments.xml — only for annotations with notes/tags.
    if (commentable.isNotEmpty) {
      final commentBlocks =
          commentable.map((e) => _buildComment(xmlId: e.key, a: e.value)).join('\n');
      final commentsXml =
          '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
          '<w:comments'
          ' xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'
          ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"'
          ' xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"'
          '>\n'
          '$commentBlocks\n'
          '</w:comments>';
      archive =
          _replaceOrAddEntry(archive, 'word/comments.xml', utf8.encode(commentsXml));
      archive = _ensureRelsEntry(archive);
    } else {
      // No comments needed — write an empty comments.xml to keep the package valid
      // if one already existed (avoids dangling relationship).
      final existing = _entryString(archive, 'word/comments.xml');
      if (existing != null) {
        const empty =
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<w:comments xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>';
        archive =
            _replaceOrAddEntry(archive, 'word/comments.xml', utf8.encode(empty));
      }
    }

    archive = _ensureContentType(archive);
    archive = _injectNativeFormatting(archive, annotations);

    await _writeArchive(archive);
  }

  // ---------------------------------------------------------------------------
  // _injectNativeFormatting
  //
  // For each annotation:
  //   1. Locate the selected text in document.xml via _buildPlainMap.
  //   2. Split runs at the span boundaries so the annotation covers exactly
  //      its selected text.
  //   3. Inject the appropriate <w:rPr> property into those runs.
  //   4. Wrap each modified run in a <w:rPrChange w:author="Léamh"> so
  //      Word shows it as a tracked formatting change and Phase 2 can
  //      recover the annotation structurally.
  //   5. For annotations with notes/tags, also inject comment anchors.
  //   6. For bookmarks, inject <w:bookmarkStart>/<w:bookmarkEnd>.
  // ---------------------------------------------------------------------------
  // _injectNativeFormatting
  //
  // For each annotation:
  //   1. Locate the selected text in document.xml via _buildPlainMap.
  //   2. Inject the appropriate <w:rPr> property into all overlapping runs,
  //      with a <w:rPrChange w:author="Léamh"> tracking the original state.
  //   3. For annotations with notes/tags, inject comment anchors.
  //   4. For bookmarks, inject <w:bookmarkStart>/<w:bookmarkEnd>.
  //
  // All insertions are collected on the ORIGINAL xml offsets and applied in a
  // single reverse-sorted pass to avoid offset drift.
  // ---------------------------------------------------------------------------

  Archive _injectNativeFormatting(
      Archive archive, List<Annotation> annotations) {
    final raw = _entryString(archive, 'word/document.xml');
    if (raw == null) return archive;

    // Strip all previous Léamh markup for a clean rewrite.
    var xml = _stripLeamhMarkup(raw);

    final map = _buildPlainMap(xml);
    if (map.plain.isEmpty) return archive;

    // Single unified insertion list: all modifications are string insertions
    // at absolute positions in the ORIGINAL (post-strip) xml.
    // Applied in reverse position order so earlier insertions don't shift later ones.
    final insertions = <({int pos, String tag})>[];

    final runOpenRe = RegExp(r'<w:r(?:\s[^>]*)?>');
    final allRunOpens = runOpenRe.allMatches(xml).toList();
    final allRunCloses = RegExp(r'</w:r>').allMatches(xml).toList();

    // Assign comment XML IDs only to annotations that need comments.
    int commentIdx = 0;
    final commentIds = <int, int>{};
    for (int i = 0; i < annotations.length; i++) {
      final a = annotations[i];
      if ((a.note != null && a.note!.isNotEmpty) || a.tag != null) {
        commentIds[i] = commentIdx++;
      }
    }

    for (int i = 0; i < annotations.length; i++) {
      final a = annotations[i];
      final loc = _locateInPlain(map.plain, a.selectedText, a.prefix, a.suffix);
      if (loc == null) {
        debugPrint('DocxStore: cannot locate "${a.selectedText}" — skipping');
        continue;
      }
      debugPrint('DocxStore: located "${a.selectedText.substring(0, a.selectedText.length.clamp(0, 30))}" at plain ${loc.start}–${loc.end} of ${map.plain.length}');

      final startXmlOffset = map.xmlOffsets[loc.start];
      final endXmlOffset = map.xmlOffsets[loc.end - 1];

      // Find run containing the start character (for anchor placement).
      RegExpMatch? startRunOpen;
      for (final m in allRunOpens) {
        if (m.start <= startXmlOffset) startRunOpen = m;
        else break;
      }

      // Find run containing the end character.
      RegExpMatch? endRunClose;
      for (final m in allRunCloses) {
        if (m.end > endXmlOffset) { endRunClose = m; break; }
      }

      if (startRunOpen == null || endRunClose == null) {
        debugPrint('DocxStore: run boundary not found for "${a.selectedText}" — skipping');
        continue;
      }

      final dateStr = a.timestamp.toUtc().toIso8601String();
      final safeId = a.id.replaceAll(RegExp(r'[^a-zA-Z0-9_]'), '_');

      if (a.tool == AnnotationTool.bookmark) {
        insertions
          ..add((pos: startRunOpen.start, tag: '<w:bookmarkStart w:id="$i" w:name="leamh_$safeId"/>'))
          ..add((pos: endRunClose.end,    tag: '<w:bookmarkEnd w:id="$i"/>'));
        continue;
      }

      final rPrContent = _rPrForTool(a.tool);
      if (rPrContent.isEmpty) continue;

      // Inject rPr into every run that overlaps [startXmlOffset, endXmlOffset].
      for (final runOpen in allRunOpens) {
        RegExpMatch? runClose;
        for (final m in allRunCloses) {
          if (m.start > runOpen.start) { runClose = m; break; }
        }
        if (runClose == null) continue;
        if (runClose.start <= startXmlOffset) continue;
        if (runOpen.start > endXmlOffset) break;

        final existingRPr = _extractRPr(xml, runOpen);
        final rPrChange =
            '<w:rPrChange w:id="$i" w:author="Léamh" w:date="$dateStr">' +
            '<w:rPr>$existingRPr</w:rPr>' +
            '</w:rPrChange>';

        final runText = xml.substring(runOpen.end, runClose.start);
        final rPrCloseIdx = runText.indexOf('</w:rPr>');
        final hasRPr = rPrCloseIdx >= 0 &&
            (runText.indexOf('<w:rPr') < (runText.contains('<w:t') ? runText.indexOf('<w:t') : runText.length));

        if (hasRPr) {
          // Inject property + rPrChange just before the existing </w:rPr>.
          final insertPos = runOpen.end + rPrCloseIdx;
          insertions.add((pos: insertPos, tag: '$rPrContent$rPrChange'));
        } else {
          // No existing rPr — insert a new one right after <w:r...>.
          insertions.add((
            pos: runOpen.end,
            tag: '<w:rPr>$rPrContent$rPrChange</w:rPr>',
          ));
        }
      }

      // Comment anchors for annotations that carry a note or tag.
      if (commentIds.containsKey(i)) {
        final cId = commentIds[i]!;
        insertions
          ..add((pos: startRunOpen.start, tag: '<w:commentRangeStart w:id="$cId"/>'))
          ..add((
            pos: endRunClose.end,
            tag: '<w:commentRangeEnd w:id="$cId"/>' +
                '<w:r><w:rPr><w:rStyle w:val="CommentReference"/></w:rPr>' +
                '<w:commentReference w:id="$cId"/></w:r>',
          ));
      }
    }

    // Apply ALL insertions in a single reverse-position pass so no offset shifts.
    insertions.sort((a, b) => b.pos.compareTo(a.pos));
    for (final ins in insertions) {
      xml = xml.substring(0, ins.pos) + ins.tag + xml.substring(ins.pos);
    }

    return _replaceOrAddEntry(archive, 'word/document.xml', utf8.encode(xml));
  }

  // for use in <w:rPrChange>. Returns empty string if no rPr exists.
  static String _extractRPr(String xml, RegExpMatch runOpen) {
    // Look for <w:rPr> immediately following the run open tag.
    final afterOpen = xml.substring(runOpen.end);
    final rPrStart = afterOpen.indexOf('<w:rPr>');
    if (rPrStart < 0 || rPrStart > 5) return ''; // not immediately after
    final rPrEnd = afterOpen.indexOf('</w:rPr>');
    if (rPrEnd < 0) return '';
    // Return content between <w:rPr> and </w:rPr>, excluding rPrChange itself.
    var content = afterOpen.substring(rPrStart + 7, rPrEnd);
    // Strip any existing rPrChange to avoid nesting.
    content = content.replaceAll(
        RegExp(r'<w:rPrChange[^>]*>.*?</w:rPrChange>', dotAll: true), '');
    return content;
  }

  // Strips all Léamh-injected markup from document.xml for a clean rewrite.
  static String _stripLeamhMarkup(String xml) => xml
      // Comment anchors
      .replaceAll(RegExp(r'<w:commentRangeStart[^/]*/>', dotAll: true), '')
      .replaceAll(RegExp(r'<w:commentRangeEnd[^/]*/>', dotAll: true), '')
      .replaceAll(
          RegExp(
              r'<w:r><w:rPr><w:rStyle w:val="CommentReference"/></w:rPr><w:commentReference[^/]*/></w:r>',
              dotAll: true),
          '')
      // Léamh bookmarks
      .replaceAll(
          RegExp(r'<w:bookmarkStart w:id="[^"]*" w:name="leamh_[^"]*"/>',
              dotAll: true),
          '')
      .replaceAll(RegExp(r'<w:bookmarkEnd w:id="[^"]*"/>', dotAll: true), '')
      // rPr properties injected by Léamh (identified via rPrChange author)
      // Strip the rPrChange blocks first, then the run properties that preceded them.
      .replaceAll(
          RegExp(
              r'<w:rPrChange w:id="[^"]*" w:author="Léamh"[^>]*>.*?</w:rPrChange>',
              dotAll: true),
          '')
      // Remove Léamh-injected highlight/underline/strike that are now orphaned
      // (their rPrChange was the marker; stripping them here is safe because
      // the original document never had Léamh's properties on these runs).
      .replaceAll(RegExp(r'<w:highlight w:val="yellow"/>(?=\s*</w:rPr>|<w:(?!rPrChange))'), '')
      .replaceAll(RegExp(r'<w:u w:val="(?:single|double|wave)"/>(?=\s*</w:rPr>|<w:(?!rPrChange))'), '')
      .replaceAll(RegExp(r'<w:strike/>(?=\s*</w:rPr>|<w:(?!rPrChange))'), '')
      // Clean up empty <w:rPr/> or <w:rPr></w:rPr> left after stripping.
      .replaceAll(RegExp(r'<w:rPr>\s*</w:rPr>', dotAll: true), '')
      .replaceAll('<w:rPr/>', '');

  // ---------------------------------------------------------------------------
  // Plain-text map  (XML offset ↔ plain-text index)
  // ---------------------------------------------------------------------------

  static ({String plain, List<int> xmlOffsets}) _buildPlainMap(String xml) {
    final buf = StringBuffer();
    final offsets = <int>[];

    // Match both <w:t> text runs and </w:p> paragraph ends.
    // </w:p> emits a '\n' so the plain text matches docxToText output,
    // allowing cross-paragraph selections to be located correctly.
    final re = RegExp(r'<w:t(?:[^>]*)>(.*?)</w:t>|</w:p>', dotAll: true);
    for (final m in re.allMatches(xml)) {
      if (m.group(0) == '</w:p>') {
        buf.write('\n');
        offsets.add(m.start);
      } else {
        final text = _unesc(m.group(1)!);
        final base = m.start + m.group(0)!.indexOf('>') + 1;
        for (int i = 0; i < text.length; i++) {
          buf.write(text[i]);
          offsets.add(base + i);
        }
      }
    }
    return (plain: buf.toString(), xmlOffsets: offsets);
  }

  static String _normaliseQuotes(String s) => s
      .replaceAll('“', '"')
      .replaceAll('”', '"')
      .replaceAll('‘', "'")
      .replaceAll('’', "'")
      .replaceAll('–', '-')
      .replaceAll('—', '-');

  static ({int start, int end})? _locateInPlain(
      String plain, String selectedText, String prefix, String suffix) {
    if (selectedText.isEmpty) return null;

    if (prefix.isNotEmpty || suffix.isNotEmpty) {
      final needle = prefix + selectedText + suffix;
      final idx = plain.indexOf(needle);
      if (idx >= 0) {
        final start = idx + prefix.length;
        return (start: start, end: start + selectedText.length);
      }
    }
    final idx = plain.indexOf(selectedText);
    if (idx >= 0) return (start: idx, end: idx + selectedText.length);

    final plainN = _normaliseQuotes(plain);
    final selectedN = _normaliseQuotes(selectedText);
    final prefixN = _normaliseQuotes(prefix);
    final suffixN = _normaliseQuotes(suffix);

    if (prefixN.isNotEmpty || suffixN.isNotEmpty) {
      final needle = prefixN + selectedN + suffixN;
      final idx2 = plainN.indexOf(needle);
      if (idx2 >= 0) {
        final start = idx2 + prefixN.length;
        return (start: start, end: start + selectedN.length);
      }
    }
    final idx2 = plainN.indexOf(selectedN);
    if (idx2 >= 0) return (start: idx2, end: idx2 + selectedN.length);

    return null;
  }

  // ---------------------------------------------------------------------------
  // Archive helpers
  // ---------------------------------------------------------------------------

  Archive _replaceOrAddEntry(Archive archive, String name, List<int> data) {
    final newArchive = Archive();
    for (final file in archive.files) {
      if (file.name != name) newArchive.addFile(file);
    }
    newArchive.addFile(ArchiveFile(name, data.length, data));
    return newArchive;
  }

  Archive _ensureContentType(Archive archive) {
    const entryName = '[Content_Types].xml';
    var raw = _entryString(archive, entryName);
    if (raw == null) return archive;

    const commentsOverride = 'PartName="/word/comments.xml"';
    if (!raw.contains(commentsOverride)) {
      const insertion = '<Override PartName="/word/comments.xml"'
          ' ContentType="application/vnd.openxmlformats-officedocument'
          '.wordprocessingml.comments+xml"/>';
      raw = raw.replaceFirst('</Types>', '$insertion\n</Types>');
    }

    const jsonDefault = 'Extension="json"';
    if (!raw.contains(jsonDefault)) {
      const insertion =
          '<Default Extension="json" ContentType="application/json"/>';
      raw = raw.replaceFirst('</Types>', '$insertion\n</Types>');
    }

    return _replaceOrAddEntry(archive, entryName, utf8.encode(raw));
  }

  Archive _ensureRelsEntry(Archive archive) {
    const entryName = 'word/_rels/document.xml.rels';
    final raw = _entryString(archive, entryName);
    if (raw == null) return archive;
    if (raw.contains('comments.xml')) return archive;

    const rel = '<Relationship Id="rId_leamh_comments"'
        ' Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"'
        ' Target="comments.xml"/>';

    final updated =
        raw.replaceFirst('</Relationships>', '$rel\n</Relationships>');
    return _replaceOrAddEntry(archive, entryName, utf8.encode(updated));
  }

  // ---------------------------------------------------------------------------
  // fractionForText  (uses docxToText — same extraction as the reader)
  // ---------------------------------------------------------------------------

  @override
  Future<double> fractionForText(
      String selectedText, String prefix, String suffix) async {
    try {
      final bytes = await File(filePath).readAsBytes();
      final plain = docxToText(bytes);
      if (plain.isEmpty) return 0.0;
      final loc = _locateInPlain(plain, selectedText, prefix, suffix);
      if (loc == null) return 0.0;
      return (loc.start / plain.length).clamp(0.0, 1.0);
    } catch (e) {
      debugPrint('DocxStore.fractionForText error: $e');
      return 0.0;
    }
  }

  Future<void> _writeArchive(Archive archive) async {
    final outBytes = ZipEncoder().encode(archive)!;
    await File(filePath).writeAsBytes(outBytes, flush: true);
  }
}
